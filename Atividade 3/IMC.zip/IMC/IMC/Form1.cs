namespace IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            double Peso;

            if (!Double.TryParse(txtPeso.Text, out Peso))
            {
                MessageBox.Show("Valor peso inv�lido!");
            }
            else
                if (Peso <= 0)
            {
                MessageBox.Show("Peso deve ser maior que zero");
            }
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            double Altura;

            if (!Double.TryParse(txtAltura.Text, out Altura))
            {
                MessageBox.Show("Valor altura inv�lido!");
            }
            else
                if (Altura <= 0)
            {
                MessageBox.Show("Altura deve ser maior que zero");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double Peso;

            if (!Double.TryParse(txtPeso.Text, out Peso))
            {
                MessageBox.Show("Valor peso inv�lido!");
                txtPeso.Focus();
            }
            else
                if (Peso <= 0)
            {
                MessageBox.Show("Peso deve ser maior que zero");
                txtPeso.Focus();
            }
            else
            {
                double Altura;

                if (!Double.TryParse(txtAltura.Text, out Altura))
                {
                    MessageBox.Show("Valor altura inv�lido!");
                    txtAltura.Focus();
                }
                else
                    if (Altura <= 0)
                {
                    MessageBox.Show("Altura deve ser maior que zero");
                    txtAltura.Focus();
                }
                else
                {
                    double IMC;

                    IMC = Peso / (Altura * Altura);
                    IMC = Math.Round(IMC, 1);
                    txtIMC.Text = IMC.ToString("N1");

                    if (IMC < 18.5)
                    MessageBox.Show("Muito magro - Coma mais!");
                    else
                        if (IMC <= 24.9)
                        MessageBox.Show("Normal - Continue assim");
                    
                    else
                        if (IMC <= 29.9)
                    
                        MessageBox.Show("Sobrepeso - Hora de come�ar se preocupar");
                    
                    else
                    if (IMC <= 39.9)
                    
                        MessageBox.Show("Obesidade - Hora de come�ar dieta");
                    
                    else 
                        if (IMC > 40)
                    
                            MessageBox.Show("Obesidade grave - Iniciar dieta agora");             

                }
            }
        }
    }
}