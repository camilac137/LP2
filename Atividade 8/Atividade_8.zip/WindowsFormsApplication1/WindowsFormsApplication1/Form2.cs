﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacos_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach (char letra in rchTexto.Text)
            {
                if (Char.IsWhiteSpace(letra))
                {
                    cont += 1;
                }
            }
            MessageBox.Show("O número de espaços em branco é " + cont);
        }

        private void btnCaracteres_Click(object sender, EventArgs e)
        {
            char c = '\0';
            int cont = 0;
            string frase = rchTexto.Text.ToUpper();
            foreach (char letra in frase)
            {
                if (letra == c)
                {
                    cont += 1;
                }
                c = letra;
            }
            MessageBox.Show("O número pares de caracteres repetidos é " + cont);
        }

        private void btnLetraR_Click(object sender, EventArgs e)
        {
            int cont = 0;
            string texto = rchTexto.Text.ToUpper();
            foreach (char letra in texto)
            {
                if (letra == 'R')
                {
                    cont += 1;
                }
            }
            MessageBox.Show("O número de caracteres R é " + cont);
        }
    }
}
