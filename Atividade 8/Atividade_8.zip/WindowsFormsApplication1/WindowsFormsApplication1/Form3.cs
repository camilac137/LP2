﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double n;
            double h = 0;
            double i;

            if (!Double.TryParse(txtNumeroN.Text, out n))
            {
                MessageBox.Show("N precisa ser um valor numérico!");
                txtNumeroN.Clear();
            }
            else
            {
                if (n <= 0)
                {
                    MessageBox.Show("N precisa ser maior que 0");
                    txtNumeroN.Clear();
                }
                else
                {
                    for (i = 1; i < n; i++)
                    {
                        h += 1 / i;
                    }
                    h += 1 / n;
                    MessageBox.Show("O valor de H é " + h);
                }
            }
        }
    }
}
