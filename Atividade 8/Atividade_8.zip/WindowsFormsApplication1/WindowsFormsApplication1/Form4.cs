﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnTeste_Click(object sender, EventArgs e)
        {
            string frase = txtFrase.Text.ToUpper();
            frase = frase.Replace(" ","");
            if (frase.Length > 50)
            {
                MessageBox.Show("Número de caracteres acima do permitido");
            }
            else
            {
                string auxiliar = frase;
                char[] arr = auxiliar.ToCharArray();
                Array.Reverse(arr);
                auxiliar = "";
                foreach (char c in arr)
                {
                    auxiliar = auxiliar + c.ToString();
                }
                if (auxiliar == frase)
                {
                    MessageBox.Show("São palíndromos!");
                }
                else
                {
                    MessageBox.Show("Não são palíndromos!");
                }
            }
        }
    }
}
