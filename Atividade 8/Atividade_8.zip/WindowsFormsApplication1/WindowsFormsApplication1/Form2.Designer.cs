﻿namespace WindowsFormsApplication1
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTexto = new System.Windows.Forms.RichTextBox();
            this.btnEspacos = new System.Windows.Forms.Button();
            this.btnLetraR = new System.Windows.Forms.Button();
            this.btnCaracteres = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTexto
            // 
            this.rchTexto.Location = new System.Drawing.Point(4, 3);
            this.rchTexto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rchTexto.Name = "rchTexto";
            this.rchTexto.Size = new System.Drawing.Size(526, 211);
            this.rchTexto.TabIndex = 0;
            this.rchTexto.Text = "";
            // 
            // btnEspacos
            // 
            this.btnEspacos.Location = new System.Drawing.Point(4, 222);
            this.btnEspacos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEspacos.Name = "btnEspacos";
            this.btnEspacos.Size = new System.Drawing.Size(170, 70);
            this.btnEspacos.TabIndex = 1;
            this.btnEspacos.Text = "Espaços em branco";
            this.btnEspacos.UseVisualStyleBackColor = true;
            this.btnEspacos.Click += new System.EventHandler(this.btnEspacos_Click);
            // 
            // btnLetraR
            // 
            this.btnLetraR.Location = new System.Drawing.Point(182, 222);
            this.btnLetraR.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLetraR.Name = "btnLetraR";
            this.btnLetraR.Size = new System.Drawing.Size(170, 70);
            this.btnLetraR.TabIndex = 2;
            this.btnLetraR.Text = "Letra \"R\"";
            this.btnLetraR.UseVisualStyleBackColor = true;
            this.btnLetraR.Click += new System.EventHandler(this.btnLetraR_Click);
            // 
            // btnCaracteres
            // 
            this.btnCaracteres.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracteres.Location = new System.Drawing.Point(360, 222);
            this.btnCaracteres.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCaracteres.Name = "btnCaracteres";
            this.btnCaracteres.Size = new System.Drawing.Size(170, 70);
            this.btnCaracteres.TabIndex = 3;
            this.btnCaracteres.Text = "Caracteres repetidos";
            this.btnCaracteres.UseVisualStyleBackColor = true;
            this.btnCaracteres.Click += new System.EventHandler(this.btnCaracteres_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 299);
            this.Controls.Add(this.btnCaracteres);
            this.Controls.Add(this.btnLetraR);
            this.Controls.Add(this.btnEspacos);
            this.Controls.Add(this.rchTexto);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio1";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTexto;
        private System.Windows.Forms.Button btnEspacos;
        private System.Windows.Forms.Button btnLetraR;
        private System.Windows.Forms.Button btnCaracteres;
    }
}