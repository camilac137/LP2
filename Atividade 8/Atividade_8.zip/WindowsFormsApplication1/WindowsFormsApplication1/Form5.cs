﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double producao;
            double salario;
            double gratificacao;
            double salarioBruto = 0;
            double A = 0;
            double B = 0;
            double C = 0;
            double D = 0;
            if (!Double.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Insira apenas valores numéricos!");
                txtProducao.Clear();
                txtSalario.Clear();
                txtGratificacao.Clear();
                txtProducao.Focus();
            }
            else
            {
                if (!Double.TryParse(txtSalario.Text, out salario))
                {
                    MessageBox.Show("Insira apenas valores numéricos!");
                    txtProducao.Clear();
                    txtSalario.Clear();
                    txtGratificacao.Clear();
                    txtProducao.Focus();
                }
                else
                {
                    if (!Double.TryParse(txtGratificacao.Text, out gratificacao))
                    {
                        MessageBox.Show("Insira apenas valores numéricos!");
                        txtProducao.Clear();
                        txtSalario.Clear();
                        txtGratificacao.Clear();
                        txtProducao.Focus();
                    }
                    else
                    {
                        A = salario;
                        if(producao>=100){
                            B = 1;
                            C = 0;
                            D = 0;
                        }
                        else
                        {
                            if(producao>=120){
                                B = 1;
                                C = 1;
                                D = 0;
                            }
                            else
                            {
                                if(producao>=150){
                                    B = 1;
                                    C = 1;
                                    D = 1;
                                }
                            }
                        }
                        salarioBruto = A + A * (0.05 * B + 0.1 * C + 0.1 * D) + gratificacao;
                        if (salarioBruto >= 7000)
                        {
                            if (!(producao >= 150 && gratificacao > 0))
                            {
                                salarioBruto = 7000;
                            }
                        }
                    }
                    lblDados.Text = "O funcionário " + txtNome.Text + " da área de " + cbxCargo.Text + ", matrícula: " + txtMatricula.Text + " .Recebeu salário bruto igual a R$" + salarioBruto;
                }
            }
        }
    }
}
